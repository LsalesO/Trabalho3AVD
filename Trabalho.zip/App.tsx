import { StatusBar } from 'expo-status-bar'; // Importando biblioteca que será utilizada
import React, { useEffect, useRef, useState } from 'react'; // importando user efect para observer variavel e user state para declarar variavel
import { FlatList, StyleSheet, TouchableOpacity, Text, TextInput, View } from 'react-native'; // importando componentes do react native

import AsyncStorage from '@react-native-async-storage/async-storage'; // salva as coisas

interface IDados {
  nome: string,
  email: string,
  telefone: string,
  id: string
} // tipagem dos dados

export default function App() {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');

  const [dados, setDados] = useState<IDados[]>([]); // tipando a variavel cadastros apra saber que é do tipo array de objetos

  useEffect(() => { //recebe dois parâmetros, uma variavel que vai ser executado e outro que vai ser observada
    async function loadData() {
      const storagedDados = await AsyncStorage.getItem('@meusdados');
      if (storagedDados) {
        setDados(JSON.parse(storagedDados));
      }
    }
    loadData();
  }, []); //pega os itens do asyncstorage e coloca na variavel cadastro

  useEffect(() => {
    async function saveData() {
      await AsyncStorage.setItem('@meusdados', JSON.stringify(dados));
    }
    saveData();
  }, [dados]); // Salva o que está na variavel cadastro dentro do asyncstorage

  function pressButton() { 
    setDados([{ nome, email, telefone, id:Math.random().toString() }, ...dados]);
    setNome("");
    setEmail("");
    setTelefone("");
  }

  function deleteItem(id: string) { // percorre o array e filtrando todas que não são igual ao nome passado, após isso ele altera cadastros
    const i = dados.filter(i => i.id !== id);
    setDados(i);
  }
  

  // parte que será exibida na tela
  return (
    <View style={styles.container}>

      <View style={styles.wrapper} >
        <Text style={styles.title} >Preencha os Dados</Text>
        <TextInput
          style={styles.input}
          placeholder="Digite seu nome..."
          onChangeText={text => setNome(text)}
          defaultValue={nome}
        />
        <TextInput
          style={styles.input}
          placeholder="Digite seu email..."
          onChangeText={text => setEmail(text)}
          defaultValue={email}
        />
        <TextInput
          style={styles.input}
          placeholder="Digite seu telefone..."
          onChangeText={text => setTelefone(text)}
          defaultValue={telefone}
        />
        <TouchableOpacity
          style={styles.button}
          onPress={pressButton}
        >
          <Text>Salvar</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.wrapper} >
        <FlatList //Passa em uma lista  oque será renderizado
          data={dados}
          renderItem={({ item }) =>
            <View key={item.id} style={styles.dado} >
              <Text onPress={() => { deleteItem(item.id) }}> Nome: {item.nome} </Text>
              <Text> Email: {item.email} </Text>
              <Text> Telefone: {item.telefone} </Text>  
            </View>}
        />
      </View>

    </View>
  );
}

//estilo 
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    paddingHorizontal: 100,
    height: '100vh',
    justifyContent: 'center',
    alignItems: 'center'
  },
  wrapper: {
    height: '50%',
  },
  title: {
    fontSize: 50,
    borderBottomWidth: 1
  },
  dado: {
    borderRadius: 4,
    borderWidth: 1,
    borderColor: 'black',
    marginVertical: 3,
  },
  input: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    marginVertical: 5,
    borderWidth: 1,
    borderStyle: 'dashed'
  },
  button: {
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderStyle: 'solid',
    borderWidth: 1
  }
});
